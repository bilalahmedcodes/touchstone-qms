@extends('layouts.user')

@section('title', 'Dashboard')


@section('content')



@endsection
