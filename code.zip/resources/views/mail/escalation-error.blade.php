<h3 style="color: red">The Escalation Details of the Agent are Missing</h3>
Agent Name: {{ $agent }} <br>
Record ID: {{ $recordId }} <br>
Phone Number: {{ $phone }} <br>
Evaluation Date: {{ $created_date }} <br>
Manager: {{ $manager }} <br>
Director: {{ $director }} <br>
<h4>QA Evaluation Feedback:</h4>
<p>{{ $notes }}</p>
