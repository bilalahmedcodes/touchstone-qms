<h3>The Escalation Feedback of your Agent:</h3>
Agent Name: {{ $agent }} <br>
Record ID: {{ $recordId }} <br>
Phone Number: {{ $phone }} <br>
Evaluation Date: {{ $created_date }} <br>

<h4>QA Evaluation Feedback:</h4>

<p>{{ $notes }}</p>
